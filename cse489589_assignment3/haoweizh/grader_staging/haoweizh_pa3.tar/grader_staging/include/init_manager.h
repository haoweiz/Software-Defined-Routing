#ifndef _INIT_MANAGER_H_
#define _INIT_MANAGER_H_

void init_response(int sock_index, char *cntrl_payload, uint16_t payload_len);

#endif
