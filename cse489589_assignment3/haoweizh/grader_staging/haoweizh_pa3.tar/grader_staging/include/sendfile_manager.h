#ifndef _SENDFILE_MANAGER_H_
#define _SENDFILE_MANAGER_H_

void sendfile_response(int sock_index, char *cntrl_payload, uint16_t payload_len);

#endif
