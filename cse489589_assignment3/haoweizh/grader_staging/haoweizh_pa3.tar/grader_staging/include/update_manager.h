#ifndef _UPDATE_MANAGER_H_
#define _UPDATE_MANAGER_H

void update_response(int sock_index, char *cntrl_payload);

#endif
