#ifndef _CRASH_MANAGER_H_
#define _CRASH_MANAGER_H

void crash_response(int sock_index);

#endif
