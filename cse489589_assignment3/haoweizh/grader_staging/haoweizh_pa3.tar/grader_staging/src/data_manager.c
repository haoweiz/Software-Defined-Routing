#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/queue.h>
#include <string.h>

#include "../include/data_manager.h"
#include "../include/global.h"


