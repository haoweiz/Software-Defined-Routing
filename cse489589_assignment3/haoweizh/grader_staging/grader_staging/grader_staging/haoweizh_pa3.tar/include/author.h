#ifndef AUTHOR_H_
#define AUTHOR_H_

void author_response(int sock_index);

#endif