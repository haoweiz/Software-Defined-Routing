#ifndef _DATA_HANDLER_H_
#define _DATA_HANDLER_H_

int new_data_conn(int data_socket);

#endif
