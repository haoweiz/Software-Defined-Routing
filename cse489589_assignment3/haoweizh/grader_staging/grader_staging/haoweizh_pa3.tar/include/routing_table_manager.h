#ifndef _ROUTING_TABLE_MANAGER_H_
#define _ROUTING_TABLE_MANAGER_H_

void routing_table_response(int sock_index);

#endif
